# Puts a faint, softened photo behind a scene (under its colour wash and zones).
# The photo is shrunk and embedded in the SVG, because SVGs shown through <img>
# can't load separate image files. Running it again replaces the old backdrop.
#
#   powershell -File images\add-backdrop.ps1 -Scene moxies-scene.svg -Photo moxies-bg-original.jpg
#   (add -Opacity 0.2 for a stronger photo, -Remove to take it out)
param(
  [Parameter(Mandatory = $true)][string]$Scene,
  [string]$Photo,
  [double]$Opacity = 0.16,
  [int]$Width = 1400,
  [switch]$Remove
)
Add-Type -AssemblyName System.Drawing
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$scenePath = Join-Path $dir $Scene
$svg = [IO.File]::ReadAllText($scenePath)

# Drop any previous backdrop.
$svg = [regex]::Replace($svg, '\s*<image id="backdrop"[^>]*/>', '')

if (-not $Remove) {
  $src = [Drawing.Image]::FromFile((Join-Path $dir $Photo))
  $h = [int][Math]::Round($src.Height * $Width / $src.Width)
  $bmp = New-Object Drawing.Bitmap $Width, $h
  $g = [Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.DrawImage($src, 0, 0, $Width, $h)
  $codec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" }
  $params = New-Object Drawing.Imaging.EncoderParameters 1
  $params.Param[0] = New-Object Drawing.Imaging.EncoderParameter ([Drawing.Imaging.Encoder]::Quality), 70L
  $ms = New-Object IO.MemoryStream
  $bmp.Save($ms, $codec, $params)
  $g.Dispose(); $bmp.Dispose(); $src.Dispose()
  $uri = "data:image/jpeg;base64," + [Convert]::ToBase64String($ms.ToArray())

  # Scene size from the root <svg>.
  $m = [regex]::Match($svg, '<svg[^>]*width="(\d+)"[^>]*height="(\d+)"')
  $W = $m.Groups[1].Value; $H = $m.Groups[2].Value
  $tag = "`n  <image id=`"backdrop`" href=`"$uri`" width=`"$W`" height=`"$H`" preserveAspectRatio=`"xMidYMid slice`" opacity=`"$Opacity`"/>"

  # Insert straight after the first full-size base <rect> (the parchment fill),
  # so the colour wash, dots and zones all sit on top of the photo.
  $base = [regex]::Match($svg, "<rect width=`"$W`" height=`"$H`" fill=`"#f5f5f7`"/>")
  if (-not $base.Success) { throw "Couldn't find the scene's base rect." }
  $svg = $svg.Insert($base.Index + $base.Length, $tag)
}

[IO.File]::WriteAllText($scenePath, $svg, (New-Object Text.UTF8Encoding $false))
"{0}: {1:N0} KB" -f $Scene, ((Get-Item $scenePath).Length / 1KB)
