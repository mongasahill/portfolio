# Builds images/web-scene.svg from scene.template.svg by embedding the site
# screenshots (resized to JPEG) as data URIs. SVGs shown through <img> can't
# load separate image files, so the pictures have to live inside the SVG.
# Re-run after replacing any screenshot:  powershell -File images\web\build-scene.ps1
Add-Type -AssemblyName System.Drawing
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path

function To-DataUri([string]$file, [int]$width, [int]$cropHeight) {
  $src = [Drawing.Image]::FromFile((Join-Path $dir $file))
  $scale = $width / $src.Width
  $h = [int][Math]::Min([Math]::Round($src.Height * $scale), $cropHeight)
  $bmp = New-Object Drawing.Bitmap $width, $h
  $g = [Drawing.Graphics]::FromImage($bmp)
  $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g.DrawImage($src, 0, 0, $width, [int][Math]::Round($src.Height * $scale))
  $codec = [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" }
  $params = New-Object Drawing.Imaging.EncoderParameters 1
  $params.Param[0] = New-Object Drawing.Imaging.EncoderParameter ([Drawing.Imaging.Encoder]::Quality), 84L
  $ms = New-Object IO.MemoryStream
  $bmp.Save($ms, $codec, $params)
  $g.Dispose(); $bmp.Dispose(); $src.Dispose()
  "data:image/jpeg;base64," + [Convert]::ToBase64String($ms.ToArray())
}

$svg = [IO.File]::ReadAllText((Join-Path $dir "scene.template.svg"))
$svg = $svg.Replace("{{VIDYA_DESKTOP}}",  (To-DataUri "vidya-desktop.png"  1300 812))
$svg = $svg.Replace("{{LOUNGE_DESKTOP}}", (To-DataUri "lounge-desktop.png" 1300 812))
$svg = $svg.Replace("{{VIDYA_MOBILE}}",   (To-DataUri "vidya-mobile.png"   440 950))
$svg = $svg.Replace("{{LOUNGE_MOBILE}}",  (To-DataUri "lounge-mobile.png"  440 950))
$out = Join-Path (Split-Path -Parent $dir) "web-scene.svg"
[IO.File]::WriteAllText($out, $svg, (New-Object Text.UTF8Encoding $false))
"wrote $out ({0:N0} KB)" -f ((Get-Item $out).Length / 1KB)
