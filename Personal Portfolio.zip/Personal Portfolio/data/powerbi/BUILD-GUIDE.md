# Restaurant sales dashboard: Power BI build guide

**Goal:** a one-page Power BI dashboard for *Taste of the World Café* (Maven Analytics' practice dataset, Q1 2023) that answers four questions a restaurant owner would ask:

1. How is the business doing overall?
2. When are we busiest?
3. Which cuisines and dishes make the money?
4. Which menu items should we promote, reprice or cut?

Time needed: about 2–3 hours the first time.

---

## 0. Before you start

- Install **Power BI Desktop** (free) from the Microsoft Store.
- Files you'll use, all in this folder's parent `data` folder:
  - `clean/order_details.csv`: 12,234 order lines (one row per item ordered)
  - `clean/menu_items.csv`: 32 menu items with cuisine and price
  - `powerbi/frost-ink-theme.json`: colours and fonts matching your portfolio

**The numbers to check against.** If your cards show these, the model is right:

| Measure | Value |
|---|---|
| Revenue | $159,217.90 |
| Orders | 5,343 |
| Items sold | 12,097 |
| Average order value | $29.80 |
| Items per order | 2.26 |

---

## 1. Load and clean the data (Power Query)

1. **Home → Get data → Text/CSV** → pick `order_details.csv` → **Transform Data**.
2. In Power Query, set the column types:
   - `order_details_id`, `order_id`, `item_id` → Whole number
   - `order_date` → Date
   - `order_time` → Time
3. **Add Column → Custom Column**:
   - `Hour` = `Time.Hour([order_time])` (type: Whole number)
   - `Weekday` = `Date.DayOfWeekName([order_date])`
   - `Weekday No` = `Date.DayOfWeek([order_date], Day.Monday) + 1` (to sort Monday to Sunday)
4. **Data quality check:** filter `item_id` to show only *null*. You'll see **137 rows (1.1%)** where an order line has no menu item. Note it, then clear the filter. Keep the rows: they don't affect revenue, and the measures below ignore them.
5. **Home → New Source → Text/CSV** → `menu_items.csv`. Types: `menu_item_id` Whole number, `price` Fixed decimal number.
6. **Close & Apply.**

*Portfolio talking point:* "I profiled the data first and found 137 order lines with no item. I kept them out of the item metrics rather than guessing what they were."

---

## 2. Model

1. Go to **Model view**. Drag `order_details[item_id]` onto `menu_items[menu_item_id]`.
   It should be **many-to-one**, single direction (menu_items filters order_details).
2. Select `Weekday` in order_details → **Column tools → Sort by column → Weekday No**.

---

## 3. Measures (DAX)

Create a blank table for measures: **Home → Enter data**, name it `_Measures`, and load it. Then add each measure with **New measure**:

```DAX
Revenue = SUMX ( order_details, RELATED ( menu_items[price] ) )

Items Sold = COUNT ( order_details[item_id] )          // COUNT skips the 137 blanks

Orders =
CALCULATE (
    DISTINCTCOUNT ( order_details[order_id] ),
    NOT ISBLANK ( order_details[item_id] )
)

Avg Order Value = DIVIDE ( [Revenue], [Orders] )

Items per Order = DIVIDE ( [Items Sold], [Orders] )

Revenue Share =
DIVIDE ( [Revenue], CALCULATE ( [Revenue], ALL ( menu_items[category] ) ) )
```

Format `Revenue` and `Avg Order Value` as Currency (2 decimals), `Revenue Share` as Percentage (1 decimal), and `Items per Order` with 2 decimals.

### Menu engineering columns (on `menu_items`)

These use price as a stand-in for profit, because the dataset has no food costs. Say so on the dashboard.

```DAX
Qty Sold = COUNTROWS ( RELATEDTABLE ( order_details ) )

Menu Class =
VAR AvgQty   = AVERAGE ( menu_items[Qty Sold] )      // 378
VAR AvgPrice = AVERAGE ( menu_items[price] )         // $13.29
RETURN
    SWITCH (
        TRUE (),
        menu_items[Qty Sold] >= AvgQty && menu_items[price] >= AvgPrice, "Star",
        menu_items[Qty Sold] >= AvgQty,                                  "Workhorse",
        menu_items[price]    >= AvgPrice,                                "Puzzle",
        "Dud"
    )
```

---

## 4. Apply the theme

**View → Themes → Browse for themes** → `frost-ink-theme.json`.
Then **View → Page view → Fit to page**, and set **Format page → Canvas settings** to 16:9, 1280 × 720.

---

## 5. Layout

```
┌──────────────────────────────────────────────────────────────────────┐
│ Taste of the World Café · Q1 2023            [Month ▾] [Cuisine ▾]  │
├────────────┬────────────┬────────────┬──────────────────────────────┤
│  Revenue   │   Orders   │ Avg order  │  Items / order               │
├────────────┴────────────┴────────────┼──────────────────────────────┤
│  ① Orders by hour (column)            │  ② Revenue by cuisine (bar)  │
│                                       │                              │
├───────────────────────────────────────┼──────────────────────────────┤
│  ③ Menu engineering (scatter)         │  ④ Top & bottom items (bar)  │
│                                       │                              │
└───────────────────────────────────────┴──────────────────────────────┘
```

### Header
- **Text box:** "Taste of the World Café, Q1 2023". Under it, a small line: "Practice dataset from Maven Analytics."
- **Two slicers** (Dropdown style): `order_date` (by month) and `menu_items[category]`.

### KPI row: 4 Card visuals
`Revenue`, `Orders`, `Avg Order Value`, `Items per Order`. Rename each card's label to plain words ("Revenue", "Orders", "Avg order", "Items per order").

### ① Orders by hour: Clustered column chart
- X-axis: `order_details[Hour]` (set the axis type to Categorical). Y-axis: `Orders`.
- Title: **"Two rushes: lunch at 12–1 pm, dinner at 5–6 pm"**
- Make 12, 13, 17 and 18 a darker blue: **Columns → Colors → fx → Rules** on Hour.

### ② Revenue by cuisine: Clustered bar chart
- Y-axis: `menu_items[category]`. X-axis: `Revenue`. Tooltip: `Items Sold`, `Revenue Share`.
- Data labels on.
- Title: **"Italian earns the most, Asian sells the most"**

### ③ Menu engineering: Scatter chart
- X-axis: `menu_items[Qty Sold]` (Don't summarize). Y-axis: `menu_items[price]` (Don't summarize).
- Values: `menu_items[item_name]`. Legend: `menu_items[Menu Class]`. Size: `Revenue`.
- **Analytics pane:** add an *Average line* on X and on Y (these split the chart into the four classes).
- Title: **"Stars to promote, duds to rethink"**
- Footnote text box: "Price used as a stand-in for profit; the dataset has no food costs."

### ④ Top & bottom items: Clustered bar chart
- Y-axis: `menu_items[item_name]`. X-axis: `Items Sold`. Sort descending.
- **Filters on this visual → item_name → Filter type: Top N → Top 5 by Items Sold.** Duplicate the visual and set it to Bottom 5.
- Titles: **"Most ordered"** / **"Least ordered"**

---

## 6. What the dashboard should show

Use these to check your build. They're also the story for your portfolio slides:

| Question | Finding |
|---|---|
| Overall | $159.2K revenue from 5,343 orders in Jan–Mar 2023; $29.80 average order, 2.26 items. Months are steady (Feb is lower only because it's shorter). |
| When busy | Lunch peak 12–1 pm (644 and 590 orders); dinner peak 5–6 pm (618 and 595); quiet at 3 pm (354). Monday is the busiest day (881), Wednesday the quietest (680). |
| Cuisines | Italian is 31.1% of revenue from 24.4% of items; Asian sells the most items (28.7%). |
| Dishes | Hamburger is ordered most (622) but Korean Beef Bowl earns most ($10.6K). Edamame sells 620 but earns only $3.1K. |
| Menu | **Stars:** Korean Beef Bowl, Cheeseburger, Tofu Pad Thai, Steak Torta, Spaghetti & Meatballs, Orange Chicken, Eggplant Parmesan. **Duds:** Chicken Tacos (123 sold, the least), Potstickers, Cheese Quesadillas, Chips & Guacamole, Veggie Burger, Hot Dog, California Roll. |
| Big orders | Only 3.4% of orders have 5+ items, but the five biggest orders lean Italian (26 of 69 items), which points to a group or catering menu built around Italian dishes. |

### Recommendations (for the last slide)
1. **Staff and prep for two rushes,** not one long day. Use the 3 pm lull for prep.
2. **Feature the stars** (Korean Beef Bowl, Spaghetti & Meatballs) at the top of the menu.
3. **Rework or cut Chicken Tacos.** They sold 4× fewer than Steak Torta at a similar price.
4. **Pair high-volume, low-price sides with mains,** e.g. Edamame or Fries in a combo.
5. **Trial an Italian group or catering menu.**

---

## 7. Export images for the portfolio

1. Make Power BI full screen (**View → Full screen**) and take screenshots (Win + Shift + S):
   - `images/dashboard-full.png`: the whole page
   - `images/dashboard-hours.png`, `images/dashboard-cuisine.png`, `images/dashboard-menu.png`: one per visual (focus mode)
2. Put them in the portfolio's `images` folder and tell Claude. They'll replace the drawn mock-up on the site.
3. Optional: **File → Export → Export to PDF** for a copy to attach to job applications.
