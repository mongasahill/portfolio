# Quick exploratory analysis of the cleaned restaurant data (checks the numbers
# the Power BI dashboard should reproduce). Writes data\clean\findings.json.
$root  = Split-Path -Parent $MyInvocation.MyCommand.Path
$clean = Join-Path $root "clean"
$menu  = @{}; Import-Csv (Join-Path $clean "menu_items.csv") | ForEach-Object { $menu[$_.menu_item_id] = $_ }
$rows  = Import-Csv (Join-Path $clean "order_details.csv")

$nullItems = @($rows | Where-Object { $_.item_id -eq "" }).Count
$lines = foreach ($r in $rows) {
  if ($r.item_id -eq "") { continue }
  $m = $menu[$r.item_id]
  $d = [datetime]::ParseExact($r.order_date, "yyyy-MM-dd", $null)
  [pscustomobject]@{
    order_id = $r.order_id; item = $m.item_name; category = $m.category; price = [decimal]$m.price
    date = $d; hour = [int]$r.order_time.Substring(0, 2); weekday = $d.DayOfWeek.ToString(); month = $d.ToString("MMM")
  }
}

$orders  = $lines | Group-Object order_id
$revenue = ($lines | Measure-Object price -Sum).Sum
$f = [ordered]@{}
$f.date_range      = "{0:yyyy-MM-dd} to {1:yyyy-MM-dd}" -f ($lines.date | Measure-Object -Minimum).Minimum, ($lines.date | Measure-Object -Maximum).Maximum
$f.order_lines     = $rows.Count
$f.lines_no_item   = $nullItems
$f.orders          = $orders.Count
$f.items_sold      = $lines.Count
$f.revenue         = [math]::Round($revenue, 2)
$f.avg_order_value = [math]::Round($revenue / $orders.Count, 2)
$f.avg_items_order = [math]::Round($lines.Count / $orders.Count, 2)

$f.by_category = $lines | Group-Object category | ForEach-Object {
  [ordered]@{ category = $_.Name; items = $_.Count; revenue = [math]::Round(($_.Group | Measure-Object price -Sum).Sum, 2) } } | Sort-Object { -$_.revenue }

$byItem = $lines | Group-Object item | ForEach-Object {
  [ordered]@{ item = $_.Name; category = $_.Group[0].category; price = $_.Group[0].price; qty = $_.Count; revenue = [math]::Round(($_.Group | Measure-Object price -Sum).Sum, 2) } }
$f.top_qty     = $byItem | Sort-Object { -$_.qty } | Select-Object -First 5
$f.bottom_qty  = $byItem | Sort-Object { $_.qty } | Select-Object -First 5
$f.top_revenue = $byItem | Sort-Object { -$_.revenue } | Select-Object -First 5
$f.all_items   = $byItem | Sort-Object { -$_.revenue }

$f.by_hour = $orders | ForEach-Object { $_.Group[0].hour } | Group-Object | ForEach-Object { [ordered]@{ hour = [int]$_.Name; orders = $_.Count } } | Sort-Object { $_.hour }
$f.by_weekday = $orders | ForEach-Object { $_.Group[0].weekday } | Group-Object | ForEach-Object { [ordered]@{ day = $_.Name; orders = $_.Count } } | Sort-Object { -$_.orders }
$f.by_month = $lines | Group-Object month | ForEach-Object { [ordered]@{ month = $_.Name; items = $_.Count; revenue = [math]::Round(($_.Group | Measure-Object price -Sum).Sum, 2) } }

# Order size distribution and what the biggest orders contain
$f.order_size = $orders | ForEach-Object { $_.Count } | Group-Object | ForEach-Object { [ordered]@{ items = [int]$_.Name; orders = $_.Count } } | Sort-Object { $_.items }
$big = $orders | Sort-Object { -(($_.Group | Measure-Object price -Sum).Sum) } | Select-Object -First 5
$f.top5_orders = $big | ForEach-Object { [ordered]@{ order_id = $_.Name; items = $_.Count; spend = [math]::Round(($_.Group | Measure-Object price -Sum).Sum, 2)
  mix = (($_.Group | Group-Object category | Sort-Object Count -Descending | ForEach-Object { "$($_.Name) $($_.Count)" }) -join ", ") } }
$f.top5_mix = $big | ForEach-Object { $_.Group } | Group-Object category | ForEach-Object { [ordered]@{ category = $_.Name; items = $_.Count } } | Sort-Object { -$_.items }

$f | ConvertTo-Json -Depth 5 | Set-Content (Join-Path $clean "findings.json") -Encoding UTF8
$f | ConvertTo-Json -Depth 5
