# Extracts the two tables from Maven's create_restaurant_db.sql into CSVs for Power BI.
# Reads the INSERT rows as text; nothing in the SQL file is executed.
# Usage (from the Personal Portfolio folder):  powershell -File data\extract.ps1

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$sql  = Join-Path $root "raw\create_restaurant_db.sql"
$out  = Join-Path $root "clean"
New-Item -ItemType Directory -Force $out | Out-Null

$orders = New-Object System.Collections.Generic.List[object]
$menu   = New-Object System.Collections.Generic.List[object]
$table  = $null

$rxOrder = [regex]"\((\d+),\s*(\d+),\s*'([\d-]+)',\s*'([\d:]+)',\s*(\d+|NULL)\)"
$rxMenu  = [regex]"\((\d+),\s*'((?:[^']|'')*)',\s*'((?:[^']|'')*)',\s*([\d.]+)\)"

foreach ($line in [IO.File]::ReadLines($sql)) {
  if ($line -match "INSERT INTO order_details") { $table = "orders" }
  elseif ($line -match "INSERT INTO menu_items") { $table = "menu" }
  if ($table -eq "orders") {
    foreach ($m in $rxOrder.Matches($line)) {
      $orders.Add([pscustomobject]@{
        order_details_id = [int]$m.Groups[1].Value
        order_id         = [int]$m.Groups[2].Value
        order_date       = $m.Groups[3].Value
        order_time       = $m.Groups[4].Value
        item_id          = $(if ($m.Groups[5].Value -eq "NULL") { "" } else { [int]$m.Groups[5].Value })
      })
    }
  } elseif ($table -eq "menu") {
    foreach ($m in $rxMenu.Matches($line)) {
      $menu.Add([pscustomobject]@{
        menu_item_id = [int]$m.Groups[1].Value
        item_name    = $m.Groups[2].Value.Replace("''", "'")
        category     = $m.Groups[3].Value.Replace("''", "'")
        price        = [decimal]$m.Groups[4].Value
      })
    }
  }
}

$orders | Export-Csv (Join-Path $out "order_details.csv") -NoTypeInformation -Encoding UTF8
$menu   | Export-Csv (Join-Path $out "menu_items.csv")   -NoTypeInformation -Encoding UTF8
"order_details rows: $($orders.Count)"
"menu_items rows:    $($menu.Count)"
